package com.example.group12_inclass05;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MainActivity extends AppCompatActivity {

    Button threadButton, asyncButton;
    ExecutorService threadPool;
    SeekBar seekBar;
    ProgressBar progressBar;
    TextView complexityView,average,barView;
    ListView listView;
    DoWorkAsync sync;
    ListAdapter adapter;
    Boolean done;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        seekBar = findViewById(R.id.seekBar);
        asyncButton = findViewById(R.id.AsyncTask);
        threadButton = findViewById(R.id.ThreadButton);
        threadPool = Executors.newFixedThreadPool(2);
        complexityView = findViewById(R.id.ComplexView);
        complexityView.setText(seekBar.getProgress() + " " + getString(R.string.times));
        progressBar = findViewById(R.id.progressBar);
        progressBar.setEnabled(true);
        average = findViewById(R.id.averageView);
        barView = findViewById(R.id.barView);
        listView = findViewById(R.id.listView);
        progressBar.setVisibility(View.INVISIBLE);
        average.setVisibility(View.INVISIBLE);



        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                complexityView.setText(progress + " " + getString(R.string.times));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        //Generate Using Thread
        threadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                average.setVisibility(View.VISIBLE);
                threadButton.setEnabled(false);
                asyncButton.setEnabled(false);

                done = false;
                threadPool.execute(new DoWork());

            }
        });

        //Generate Using AsyncTask
        asyncButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Log","AsyncButton");
                progressBar.setVisibility(View.VISIBLE);
                average.setVisibility(View.VISIBLE);

                threadButton.setEnabled(false);
                asyncButton.setEnabled(false);

                average.setText(getString(R.string.average));
                listView.setAdapter(null);
                sync = (DoWorkAsync) new DoWorkAsync().execute(seekBar.getProgress());
            }
        });
    }

    //Async
    class DoWorkAsync extends AsyncTask<Integer,Integer,ArrayList<Double>>{

        ArrayList<Double> num;

        @Override
        protected void onPreExecute() {
            Log.d("Log", "onPreExecute");
            num = new ArrayList<>();
        }

        @Override
        protected void onPostExecute(ArrayList<Double> num) {
            Log.d("Log", "onPostExecute");
            threadButton.setEnabled(true);
            asyncButton.setEnabled(true);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            Log.d("Log", "onProgressUpdate");
            progressBar.setProgress(values[0]);
            barView.setText(values[0] + "/" + values[1]);
            sum();
        }

        @Override
        protected ArrayList<Double> doInBackground(Integer... integers) {
            Log.d("Log", "doInBackground");
            int size =  integers[0];
            progressBar.setMax(size);
            progressBar.setProgress(0);

            Log.d("Log","String Size: " + size);

            for (int i = 0; i < size; i++) {
                Log.d("Log", "Loop");
                num.add(HeavyWork.getNumber());
                publishProgress(i + 1,size);
            }

            return num;
        }
        public void sum(){
            double sum = 0;
            for (double number : num)
                sum += number;
            average.setText(getString(R.string.average) + " " + sum);
            adapter = new ArrayAdapter<>(getBaseContext(), android.R.layout.simple_list_item_1,android.R.id.text1,num);
            listView.setAdapter(adapter);
        }
    }


    // Threads
    class DoWork implements Runnable{

        ArrayList<Double> num;
        int size;
        static final int STATUS_STOP = 1000;

        Handler handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {

               if (msg.what == STATUS_STOP){
                    Log.d("Log", "Ending Thread...");
                   threadButton.setEnabled(true);
                   asyncButton.setEnabled(true);
                }
                else {
                    Log.d("Log", "On Process: " + msg.what);
                    Log.d("Log", "Getting... " + msg.obj);
                    barView.setText(msg.what + "/" + size);
                    sum();
                }

                return false;
            }
        });

        @Override
        public void run() {
            Log.d("Log", "DoWork : Run()");
            Log.d("Log", "Starting Thread...");
            //Start
            String[] string = complexityView.getText().toString().split(" ");
            size = Integer.parseInt(string[0]);
            progressBar.setMax(size);
            progressBar.setProgress(0);

            //Process
            num = new ArrayList<>();
            for (int i = 0; i < size; i++) {
                num.add(HeavyWork.getNumber());
                progressBar.setProgress(i + 1);
                Message message = new Message();
                message.what = i+1;
                message.obj = num.get(i);
                handler.sendMessage(message);
            }

            //Stop
            Message stopMessage = new Message();
            stopMessage.what = STATUS_STOP;
            handler.sendMessage(stopMessage);

        }
        public void sum(){
            Log.d("Log", "Sum");
            double sum = 0;
            for (double number : num)
                sum += number;
            average.setText(getString(R.string.average) + " " + sum);
            adapter = new ArrayAdapter<>(getBaseContext(), android.R.layout.simple_list_item_1,android.R.id.text1,num);
            listView.setAdapter(adapter);
        }
    }
}